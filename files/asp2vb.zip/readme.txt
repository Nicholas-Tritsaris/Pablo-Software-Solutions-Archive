ASP 2 VB Converter by Pablo Software Solutions

This utility converts one or more ASP source files into a single Visual Basic 6.0 project that can be compiled into a ActiveX COM DLL
for maximum performance, safety and security. Include files are integrated in the output VB classes.

The following components are required in order to use ASPLightning: 

Visual Basic 6.0 to compile the generated DLL project.
A web server that fully supports the ASP object model this includes Microsoft's IIS Web Server and of course Baby Asp Web Server 2.2 or higher.


Here's how it works:
Select a Project Root Folder, this will be the root of your ASP application.
All files in the selected folder (and optional all sub folders files) will automatically be added to the input file list.
You can also add or remove files by using the Add and Remove buttons.

Select a folder for the generated Visual Basic output files.
These files include:
One Visual Basic Class file (.cls) for each ASP script to be converted.
The Visual Basic Project file (.vbp)

Next select a folder for the output web files.
These files include:
One stub ASP script (.asp) for each ASP script to be converted.
All selected images, html and other files you've selected.

VB Startup Options:
Start VB and build project
Visual Basic will be executed in the background to compile the DLL. 

Start VB
Visual Basic will be launched, so you can review the result and compile the project manually.

Do not start VB
The Visual Basic project will be generated, but Visual Basic is not started.

Press 'Start' to convert the selected files.
The progress of the conversion will be displayed in the Status Messages window.


Known limitations:
This version will remove all ASP comments.
Only supports VBScript as the Server Side script language.
IIS directives like ENABLESESSIONSTATE, LANGUAGE, CODEPAGE will be ignored
This freeware version does not include any support from Pablo Sofware Solutions.


Copyright Pablo Software Solutions 
http://www.pablosoftwaresolutions.com

