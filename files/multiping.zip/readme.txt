Multi Ping Version 1.0 Build 002
This utility allows you to ping multiple targets.at the same time.
I created this tool to check several network connections and see which one the (in this case) servers was down. Multi Ping logs the results to a log file. Each ping command is executed in a seperate thread.
The application uses ICMP.DLL to send ping commands to the target.

Multi Ping does not have a lot of options, just a few basic features:

- Add,Edit .and Removes IPaddresses.
- Interval (in seconds).
- Ping Timeout (in milliseconds).
- Start/Stop to begin and end the ping process.
