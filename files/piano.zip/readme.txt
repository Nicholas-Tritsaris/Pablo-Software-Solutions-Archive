Virtual Piano by Pablo Software Solutions Version 1.0 Build 001

Introduction
Virtual Piano is a simple MIDI controller for  for Windows 98/NT/XP.
Almost every MIDI parameter can be change via the user interface. 

Installation
Installing Virtual Piano is as simple as unzipping the executable in a folder of you choice, for example C:\Program Files\Virtual Piano.
Create a shortcut on the Start Menu of on your desktop and the Virtual Piano will be ready to use.

� Copyright 2002 Pablo Software Solutions
http://www.pablovandermeer.nl



