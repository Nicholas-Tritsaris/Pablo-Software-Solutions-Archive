FTPService.exe is a NT/XP service-version of Quick 'n Easy FTP Server.
This service enables you to have the FTP server active even when you're not logged into windows.

Because the service has no user interface, You'll have to configure this application through a configuration applet (ftpcfg.cpl).
For more information about the settings, see the help file of Quick 'n Easy Server.

The application has the following commandline parameters:
-i	Install the service (service will show up in the service list)
-u	Uninstall the service (service will be removed from the service list)
-s	Start the service
-e	Stop the service
-c	reload USERS.XML, SECURITY.XML and registry keys

The service will only run under Windows NT4/2000/XP and not Win95/98/ME.
To Start en Stop the service, goto the Windows Service Manager (Services) in the Control Panel
Make sure the 'Local System Account' has the appropriate permissions to read/write the files you are sharing with the FTP server!


Registry keys:

All keys must be added on this location:
HKEY_LOCAL_MACHINE\SOFTWARE\Pablo Software Solutions\FTP Service\Settings

Name			Type 	Description			
Port 			DWORD 	Socket port on which new connections are excepted (default: 21).
MaxUsers		DWORD	Maximum number of users that can simultaneous be connected (default: 10).
MaxIPConnections	DWORD	Maximum number of connections per IP address (default: 3).
ThreadPriority		DWORD	Thread priority: 0, 1, 2, 3, 4 5 or 6 (default: 3), 0 is highest, 6 is lowest.
Timeout			DWORD	When a client has been idle for a specific time it will be automatically disconnected (default: 5).
IPFilterMode		DWORD	(0) - Do not use IP filter, (1) Do not accept connections from specified IP addresses, (2) Accept connections only from specified IP addresses.
Address			string	IP address for PASV mode
WelcomeMsg		string	Text that will be displayed when a client connects to the server.
GoodbyeMsg		string	Text that will be displayed when a client disconnects from the server.
ShowHiddenFiles		DWORD	Show hidden files and directories with LIST command (default: 0)
MaskPassword		DWORD	Mask password in logfile  (default: 1)
MinPassivePort  	DWORD	Minimum of the PASV mode port range (default: 1024)
MaxPassivePort  	DWORD	Maximum of the PASV mode port range (default: 65535)
TimeFormat		DWORD	Directory listing time format (Local Time: 0, Universal Time (UTC): 1)
EnableStatistics	DWORD 	Set to '1' to enable download/upload statistics, so you can keep track of who/when and what is downloaded/uploaded.
				This information is saved in a XML file called REPORTS.XML. 
DefaultHome		string	The default home directory is used when a new user is created (by a remote administator). 
				The home directory of this user will initially be set to this value.
AdminUser		string	Used by 'Online Users' to logon to the service and query for the status (executes WHO command).
AllowQuotaOverflow	DWORD	Allow quota overflow. The current upload is completed. (default: 0)
DeleteIncompleteUploads	DWORD	Enable this option if you want to remove the incomplete file(s), in case the upload fails. (default: 0)
LogLevel		DWORD	0 = None, 1 = Error, 2 = Warning, 3 = Trace



This application includes a setup.exe file, which makes it easier to setup this service.
It takes the following actions:

- Asks for install directory.
- Copies all files to this directory.
- Copies ftpcfg.cpl to the system32 directory.
- Runs ftpservice -i to install the service in the service control manager.
- Creates a default user: admin, no password, disabled, download access to C:\INETPUB.

Make sure the control panel window is closed when install/uninstall or otherwise the setup will probably fail.
You can use this same tool the uninstall the service!

Pablo Software Solutions
http://www.pablosoftwaresolutions.com