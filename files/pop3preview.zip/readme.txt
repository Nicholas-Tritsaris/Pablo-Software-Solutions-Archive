POP3 Preview by Pablo Software Solutions

POP3 Preview - Delete SPAM and Virusses before you download them.
Don�t waste your time and bandwidth by downloading spam and virussen to your inbox! 
With POP3 Preview you can check your E-Mail on the mail (POP3) server without the need to download the 
whole message. Based on the information in the header of the message (like Subject or Sender) you can decide 
if you want to keep the message or delete it from the server. 
POP3 Preview also includes a SPAM filter, that can filter messages based on the subject or sender. 
Messages that match the criteria will automatically be selected when you check for new e-mail. 
All you have to do is simply press� Purge� and the Junk E-mails are deleted from the server!


Features:
- Cool looking and easy to use user interface with keyboard shortcuts for most operations.
- Configure multiple POP3 e-mail accounts.
- Junk E-mail Filter
- Blocked Sender List
- Safe Senders List
- Preview message headers
- Import Junk E-mail subject lists from other programs or websites.
- Import E-Mail addresses from Outlook Express or the Windows Address Book.
- Already includes a large number of common subject titles of SPAM and virusses. 


Usage:
Create an e-mail account: select Account->New Account from the menu. Enter the details of your POP3 Server.
Select Receive Messages from the Menu to download the message headers.
The new messages will be displayed in the messages window. 
Now you can take one of the following actions:
Add subject to junk filter, adds the subject (or a part of it) to to Junk E-mail Filter.
Add sender to blocked list, adds the sender to the blocked senders list
Add sender to safe list, adds the sender to the safe senders list.

Includes tools to add, edit or remove items from the Junk E-Mail Filter, Blocked Senders List and Safe List.


Copyright Pablo Software Solutions 
http://www.pablovandermeer.nl

