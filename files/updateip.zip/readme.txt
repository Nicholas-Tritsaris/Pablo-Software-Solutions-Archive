Update IP Version 1.6

If you want to setup your own personal Web or FTP server, but your ISP allocates a new IP address everytime you connect, then this is the utility for you!
UpdateIP automatically updates your web pages with your current IP address, so you don't have to change them manually. And visitors of you website always have your latest IP address.
Just create an HTML template (with a link to your server) and UpdateIP will implant your current IP address and upload the file to your website.

You can configure multiple HTML pages and upload them to different servers.
UpdateIP can be configured to run only once at the computer startup or continuously scan for changes of your IP address.

Now Update IP also can send emails through SMTP to notify your friends about the IP change!

UpdateIP scans the list of IP addresses on your system and tries to determine which address is most likely the internet IP address.
Then it walks through the list of configured web sites and searches the specified HTML pages for one of the following tags:

<!--IP--!> will be replace by your current IP address.
<!--TIME--!> will be replace by the current time.
<!--DATE--!> will be replace by the current date (long date).
<!--SHORTDATE--!> will be replace by the current date (short date).
<!--FIXEDDATE--!> will be replace by the current date (MM/DD/YYYY).

After that it will upload the file to your website.

Example HTML code:

Download the latest MP3 files from ftp://<!--IP--!>
This page was last updated at <!--TIME--!>, on <!--DATE--!>

becomes:

Download the latest MP3 files from ftp://144.44.44.44  
This page was last updated at 22:51:24, on Wednesday, April 02, 2004

Also see the example file: example.html


How do I setup this utility?
You must enter the following information to setup a new 'website' job:
1. the FTP site (host) where the file will be uploaded to.
example: ftp.pablovandermeer.nl
2. your username.
3. your password.
4. the name of the (local) file you want to upload.
example: C:\WebPages\test.html
5. the remote filename.
example: test.html
or
/public/index.htm

Click 'OK' to save this information.


To notify people through email, you must enter the following information:
1. Click the Email tab.
2. Choose 'Add' to add a new email profile.
3. Enter the SMTP server (your email server)
example: smtp.myserver.com
4. Enter your own email address in the 'From' field.
example: pablo@myserver.com
5. Enter all recipients in the 'To' field.
example: britney@myserver.com
or multiple addresses:
example: britney@myserver.com, jessica@myserver.com, pamela@myserver.com
6. Enter a subject.
7. And finally the body text of the email. This text also can include all the special tags from the description above.
example:
Hi, my IP address has changed to: <!--IP--!>
This information was sent on <!--TIME--!>, on <!--DATE--!>
Cheers,
Pablo

Click 'OK' to save this information.


Under 'Settings' you can configure how UpdateIP behaves
The General settings speak for themselves (I think).
For IP monitoring you can select from 3 methods:
1. Get IP from this computer.
This is the default setting that normally works well with computers that are directly connected to the Internet.
2. Get IP using route tracing (router/gateway).
This setting uses route tracing to figure out the 'route' to a specific host. The first real Internet address it comes across will be considered the router's (or gateway) IP address.
3. Get IP from remote server.
This setting contacts a remote web server that will reveal the Internet IP address via an html page.
I came accross several web sites that provide such a service (and that work with UpdateIP):
http://checkip.dyndns.org/
http://www.showmyip.com/
http://www.aiai.ed.ac.uk/project/mcu/ip.shtml
http://www.tritechsolutions.com/cgi-local/ipaddresscheck

Just search for 'current ip address' on www.google.com to find more.

 
� Copyright 2004 Pablo Software Solutions
http://www.pablovandermeer.nl