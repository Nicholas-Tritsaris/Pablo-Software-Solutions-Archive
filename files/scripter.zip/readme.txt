Visual Scripter by Pablo Software Solutions

A few years ago I did develop a lot of Voice Response System(VRS) related software.
At the time (1995) there where not a lot of good Windows based solutions available, so at one point I thought it would be nice to create my own Voice Response System.
I never really finished to complete system, but here's the part that I did finish: Visual Scripter.
Orginally it was wriiten for a Windows NT system with NMS telephone boards, but unfortunately these boards are not sold anymore (they stopped making them in 1998).
So I've removed all telephone related code. Also I've updated most of the code to todays standards.
Since this project was lying around for some years and I don't really know what to do with it, I decided to publish this article to my website. Maybe someone is working on a simular project and likes to play with the code...

Visual Scripter is a visual script designer where the user can visually design the scripts without having a lot off programming experience.
This is a complete solution with a build in expression parser and debugger to test the created scripts.
The user can drag objects (nodes) from the toolbar to the document area and link them together using linking arrows. You can also define error links in cases a node fails to execute.

Key features:
Drag 'n drop for easy script development.
User definable variables (string and numeric) -> automatically added when first used and then integrated in the develop environment.
Build-in expression parser with Basic-like syntax with most a lot of standard functions like: AND, OR, XOR, SIN, COS, TAN, LOG, LEN, CHR, ABS, VAL, RANDOM, LEFT, MID, RIGHT, TRIM, several date and time functions and many more.
Easy database (dBase) usage.
Intergated debugger to go step by step through your script.
Undo/Redo
Cut/Copy/Paste clipboard support.
Print support
Possibility for interprocess communication between scripts or external application using Shared Memory and synchronisation objects(events).
Fun to play with...

Short description of the available nodes:
For most of the nodes you can specficy direct values or variables for their parameters. You can even use the build-in functions as parameter!
When you press OK in most cases the entered values validated. And syntax errors are displayed including the error position.

Pickup the phone
Pickup an ringing (incoming) or an available(outgoing) line.
Places the line in offhook state. Normally this node is the first in a script.

Hangup the phone
Hangup a phone line that was previously picked up with 'Pickup the phone'
Places the line in onhook state.

Transfer a call
Transfer a call from one line to another.

Play audio
Play audio file to caller.

Record audio
Record audio from caller

Get input from caller
Get input digits (response) from caller.
You can also specify a wave file that will be played to prompt the caller.

Get DTMF tones
Record a string of DTMF tones. For example to collect data from the caller.

Play DTMF tones
Play DTMF tones to the caller or outgoing line.

Wait for a call
Wait for an incoming call for a specified amount of time.

Wait for a tone
Wait for a tone for a specified amount of time.

Wait for a voice
Wait for a voice for a specified amount of time.

Connect to agent
Connect the current call to an agent

Disconnect from agent
Disconnect the current call from an agent

Wait for agent disconnect
Wait for the agent to disconnect

Sleep
Temporarily stops executing the script for a specified amount of time.

Exit script
Stops excecuting the script.

Assign variable
Assign a value to a variable. This can be a simple string or number, but also a complex expression.
Examples:

Assign a string:
Variable: myvalue$
Expression: "This" + " " + left$("iss", 1, 2) + " a test!"
Result: This is a test!

Assign a numeric:
Variable: myvalue
Expression: 10 + len("2" + "2") + val("4")
Result: 16

Insert text to logfile
Insert a line of text into the logfile.

Test expression
Compares to values (variables or expressions). 

Jump to label
Jump to a label. This node just works like a 'goto' command.

Label
Label where you can jump to. A label is automatically assigned a alphabetic character.

Call subscript
Load a subscript and execute it.

Write to shared memory
Write data shared memory. If the shared memoryblock (specified by name) 
does not exists it will be created (4k). The data will be written as a string.
This node can be used to share data between scripts or an external application.

Read from shared memory
Read data from shared memory. The shared memoryblock (specified by name) 
needs already to be created. The data will be read as a string.
This node can be used to share data between scripts or an external application.

Flag up
Raise a flag (= signaled state). This node can be used to signal another script or an external application.
A flag is a named event that can be shared between processes.
If the event does not exists it will be created.

Flag down
Lower a flag (= non-signaled state). This node can be used to put an event in non-signaled state.
A flag is a named event that can be shared between processes.
If the event does not exists it will be created.

Wait for a flag
Wait for a flag to be raised (is in signaled state).

Execute program
Execute an external application.

Open database
Open a dBase database (*.DBF)

Close database
Close a dBase database (*.DBF)

Add record to database
Add a new record to a database.

Delete record from database
Delete record from database

Goto record
Goto a specific record (top, bottom, next, previous, recno)

Search record
Search for a record

Update record
Update a value in the current record.

Lock record
Lock the current record

Unlock record
Unlock the current record.

Supported functions:
AND	Logical-and.
OR	Logical-or.
XOR	Logical-xor.
MOD	Divides two numbers and returns only the remainder.
NOT	Performs logical negation on an expression.
SQR	Calculates the square root of a number.
SQRT	Calculates the square root of the given expression.
SIN	Calculates the sine of an angle.
COS	Calculates the cosine of an angle.
TAN	Calculates the tangent of an angle.
ARCTAN	Calculates the arctangent of an angle.
LOG	Calculates the natural logarithm of a number.
EXP	Calculates the exponential.
ASC	Returns an Integer representing the character code.
LEN	Returns the length of a string.
ABS	Returns the absolute value of a number.
SGN	Returns the sign of a number.
VAL	Returns the numbers contained in a string as a numeric value.
RANDOM Returns a random number
MAX	Returns the maximum of two values.
MIN	Returns the minimum of two values.
NOW	Returns the date/time as number (01/01/1970 based).
STR$	Returns a String representation of a number.
CHR$	Returns a String containing the character associated with the specified character code.
LEFT$	Returns a String containing a specified number of characters from the left side of a string.
MID$	Returns a String containing a specified number of characters from a string.
RIGHT$	Returns a String containing a specified number of characters from the right side of a string.
TRIM$	Returns a String containing a copy of a specified string without leading spaces and trailing spaces.
LOWER$	Returns a String containing a copy of a specified string in lower case.
UPPER$	Returns a String containing a copy of a specified string in upper case.
DATE$	Returns the current date as a string.
TIME$	Returns the current time as a string.
FORMAT$ Returns a formatted string, which can be time, date or another valid format expression.

+	plus	
-	minus
*	multiply
/	divide
=	equal
<>	not equal
>=	greater than or equal
<=	less than or equal
>	greater than
<	less than
^	raise a number to the power of an exponent.
( )	grouping


Copyright Pablo Software Solutions 
http://www.pablovandermeer.nl