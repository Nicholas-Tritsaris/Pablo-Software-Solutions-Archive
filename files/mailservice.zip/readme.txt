Quick 'n Easy Mail Service 3.3

setup.exe	- Simple installation of the Mail service
mailcfg.cpl	- Configuration applet for the service (must be copied to system32 directory)
mailService.exe	- Mail service
mailservice.chm - The help file

The application has the following commandline parameters:
-i	Install the service (service will show up in the service list)
-u	Uninstall the service (service will be removed from the service list)
-s	Start the service
-e	Stop the service

The service will only run under Windows NT4/2000/XP and not Win95/98/ME.
To Start en Stop the service, goto the Windows Service Manager (Services) in the Control Panel or use the Control panel applet.

This application includes a setup.exe file, which makes it easier to setup this service.
It takes the following actions:

- Asks for install directory.
- Copies all files to this directory.
- Copies webcfg.cpl to the system32 directory.
- Runs mailservice -i to install the service in the service control manager.

You have to use this same tool the uninstall the service!

Pablo Software Solutions
http://www.pablosoftwaresolutions.com