Pablo's Cookie Viewer Version 1.0 Build 005

Cookies provide websites with a mechanism to store and retrieve state information on your computer. This mechanism allows Web-based applications the ability to store information about selected items, user preferences, registration information, and other information that can be retrieved later.
Cookies are small textfiles stored on the harddisk of your computer.

This utility shows you what kind of information web sites have stored on your computer. 
It can also delete, backup and restore cookies and has a simple Find option.

� Copyright 2004 Pablo Software Solutions
http://www.pablovandermeer.nl